package com.bettermounthud.mixin;

import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.ClickType;
import net.minecraft.world.inventory.Slot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(AbstractContainerScreen.class)
public interface AbstractContainerScreenAccessor {
    @Invoker("findSlot")
    Slot bettermounthud$invokeGetHoveredSlot(double x, double y);

    @Invoker("slotClicked")
    void bettermounthud$invokeSlotClicked(Slot slot, int index, int button, ClickType clickType);

    @Accessor("isQuickCrafting")
    boolean bettermounthud$getIsQuickCrafting();

    @Accessor("isQuickCrafting")
    void bettermounthud$setIsQuickCrafting(boolean value);

    @Accessor("quickCraftingButton")
    int bettermounthud$getQuickCraftingButton();

    @Accessor("skipNextRelease")
    void bettermounthud$setSkipNextRelease(boolean value);

    @Accessor("leftPos")
    int bettermounthud$getLeftPos();

    @Accessor("topPos")
    int bettermounthud$getTopPos();
}
