package com.bettermounthud;

public class Logger {

    public static void Log(String text) {
        System.out.println("[betterMountHud] " + text);
    }

    public static void DebugLog(String text) {
        if (Config.debug)
            System.out.println("[betterMountHud] " + text);
    }

}
