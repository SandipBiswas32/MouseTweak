package com.bettermounthud.handlers;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.world.inventory.*;
import com.bettermounthud.IGuiScreenHandler;
import com.bettermounthud.MouseButton;
import com.bettermounthud.api.BetterMountHudDisableWheelTweak;
import com.bettermounthud.api.BetterMountHudIgnore;
import com.bettermounthud.mixin.AbstractContainerScreenAccessor;

import java.util.List;

public class GuiContainerHandler implements IGuiScreenHandler {
    Minecraft mc;
    private final AbstractContainerScreen screen;
    private final AbstractContainerScreenAccessor screenAccessor;

    public GuiContainerHandler(AbstractContainerScreen screen) {
        this.mc = Minecraft.getInstance();
        this.screen = screen;
        this.screenAccessor = (AbstractContainerScreenAccessor) screen;
    }

    @Override
    public boolean isBetterMountHudDisabled() {
        return screen.getClass().isAnnotationPresent(BetterMountHudIgnore.class);
    }

    @Override
    public boolean isWheelTweakDisabled() {
        return screen.getClass().isAnnotationPresent(BetterMountHudDisableWheelTweak.class);
    }

    @Override
    public List<Slot> getSlots() {
        return screen.getMenu().slots;
    }

    @Override
    public Slot getSlotUnderMouse(double mouseX, double mouseY) {
        return screenAccessor.bettermounthud$invokeGetHoveredSlot(mouseX, mouseY);
    }

    @Override
    public boolean disableRMBDraggingFunctionality() {
        screenAccessor.bettermounthud$setSkipNextRelease(true);

        if (screenAccessor.bettermounthud$getIsQuickCrafting() && screenAccessor.bettermounthud$getQuickCraftingButton() == InputConstants.MOUSE_BUTTON_RIGHT) {
            screenAccessor.bettermounthud$setIsQuickCrafting(false);
            return true;
        }

        return false;
    }

    @Override
    public void clickSlot(Slot slot, MouseButton mouseButton, boolean shiftPressed) {
        screenAccessor.bettermounthud$invokeSlotClicked(
                slot,
                slot.index,
                mouseButton.getValue(),
                shiftPressed ? ClickType.QUICK_MOVE : ClickType.PICKUP
        );
    }

    @Override
    public boolean isCraftingOutput(Slot slot) {
        return (slot instanceof ResultSlot
                || slot instanceof FurnaceResultSlot
                || slot instanceof MerchantResultSlot);
    }

    @Override
    public boolean isIgnored(Slot slot) {
        return false;
    }
}
