# betterMountHud

Inventory management mod for Fabric 1.21.11 (client side).
Based on Mouse Tweaks by Ivan Molodetskikh (YaLTeR), BSD 3-Clause (see LICENSE).

## Build

    ./gradlew build

Jar will be in `build/libs/` (use the one without `-sources`).
Needs Fabric API. Mod Menu is optional for the config screen.
